import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { ESGProfile } from '@/types/project';
import { sdgOptions, regionOptions } from '@/data/mockData';
import { Search, Target, Globe, TrendingUp } from 'lucide-react';

interface MatchingEngineProps {
  onSearch: (profile: ESGProfile) => void;
}

export function MatchingEngine({ onSearch }: MatchingEngineProps) {
  const [profile, setProfile] = useState<ESGProfile>({
    riskAppetite: 'Balanced',
    prioritySDGs: [],
    preferredRegion: 'Any',
    minimumCredits: 5000
  });

  const handleSDGChange = (sdg: string, checked: boolean) => {
    setProfile(prev => ({
      ...prev,
      prioritySDGs: checked 
        ? [...prev.prioritySDGs, sdg]
        : prev.prioritySDGs.filter(s => s !== sdg)
    }));
  };

  const handleSearch = () => {
    onSearch(profile);
  };

  return (
    <Card className="h-fit bg-gradient-to-b from-card to-muted/20 border-border/50 shadow-lg">
      <CardHeader className="space-y-1">
        <CardTitle className="flex items-center gap-2 text-foreground">
          <Target className="h-5 w-5 text-accent" />
          Matching Engine
        </CardTitle>
        <p className="text-sm text-muted-foreground">Configure your ESG investment profile</p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Risk Appetite */}
        <div className="space-y-2">
          <Label className="text-sm font-medium text-foreground flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-trust" />
            Risk Appetite
          </Label>
          <Select
            value={profile.riskAppetite}
            onValueChange={(value: any) => setProfile(prev => ({ ...prev, riskAppetite: value }))}
          >
            <SelectTrigger className="bg-background border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Conservative">Conservative</SelectItem>
              <SelectItem value="Balanced">Balanced</SelectItem>
              <SelectItem value="High-Impact">High-Impact</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Priority SDGs */}
        <div className="space-y-3">
          <Label className="text-sm font-medium text-foreground">Priority SDGs</Label>
          <div className="grid gap-3 max-h-48 overflow-y-auto">
            {sdgOptions.map((sdg) => (
              <div key={sdg} className="flex items-center space-x-2">
                <Checkbox
                  id={sdg}
                  checked={profile.prioritySDGs.includes(sdg)}
                  onCheckedChange={(checked) => handleSDGChange(sdg, !!checked)}
                  className="border-border data-[state=checked]:bg-accent data-[state=checked]:border-accent"
                />
                <Label
                  htmlFor={sdg}
                  className="text-sm text-foreground/80 leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  {sdg}
                </Label>
              </div>
            ))}
          </div>
        </div>

        {/* Preferred Region */}
        <div className="space-y-2">
          <Label className="text-sm font-medium text-foreground flex items-center gap-2">
            <Globe className="h-4 w-4 text-trust" />
            Preferred Region
          </Label>
          <Select
            value={profile.preferredRegion}
            onValueChange={(value) => setProfile(prev => ({ ...prev, preferredRegion: value }))}
          >
            <SelectTrigger className="bg-background border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {regionOptions.map((region) => (
                <SelectItem key={region} value={region}>
                  {region}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Minimum Credits */}
        <div className="space-y-3">
          <Label className="text-sm font-medium text-foreground">
            Minimum Credits Required: {profile.minimumCredits.toLocaleString()}
          </Label>
          <Slider
            value={[profile.minimumCredits]}
            onValueChange={([value]) => setProfile(prev => ({ ...prev, minimumCredits: value }))}
            max={20000}
            min={1000}
            step={500}
            className="w-full"
          />
        </div>

        {/* Search Button */}
        <Button
          onClick={handleSearch}
          className="w-full bg-gradient-to-r from-accent to-primary hover:from-accent/90 hover:to-primary/90 text-accent-foreground font-medium shadow-md hover:shadow-lg transition-all duration-300"
        >
          <Search className="h-4 w-4 mr-2" />
          Find Matches
        </Button>
      </CardContent>
    </Card>
  );
}