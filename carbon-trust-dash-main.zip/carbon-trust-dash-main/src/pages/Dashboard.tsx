import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MatchingEngine } from '@/components/MatchingEngine';
import { ProjectCard } from '@/components/ProjectCard';
import { ESGProfile, Project } from '@/types/project';
import { mockProjects } from '@/data/mockData';
import { Leaf, TrendingUp } from 'lucide-react';

export default function Dashboard() {
  const navigate = useNavigate();
  const [filteredProjects, setFilteredProjects] = useState<Project[]>(mockProjects);

  const handleSearch = (profile: ESGProfile) => {
    let filtered = [...mockProjects];

    // Filter by minimum credits
    filtered = filtered.filter(p => p.creditsRemaining >= profile.minimumCredits);

    // Filter by region
    if (profile.preferredRegion !== 'Any') {
      filtered = filtered.filter(p => p.region === profile.preferredRegion);
    }

    // Filter by priority SDGs
    if (profile.prioritySDGs.length > 0) {
      filtered = filtered.filter(p => 
        profile.prioritySDGs.some(sdg => p.sdgs.includes(sdg))
      );
    }

    // Sort by risk appetite
    if (profile.riskAppetite === 'Conservative') {
      filtered.sort((a, b) => a.riskScore - b.riskScore);
    } else if (profile.riskAppetite === 'High-Impact') {
      filtered.sort((a, b) => b.creditsRemaining - a.creditsRemaining);
    }

    setFilteredProjects(filtered);
  };

  const handleProjectClick = (projectId: string) => {
    navigate(`/project/${projectId}`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gradient-to-br from-accent to-primary">
                <Leaf className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">CarbonTrust AI</h1>
                <p className="text-sm text-muted-foreground">Carbon Credit Intelligence Platform</p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <TrendingUp className="h-4 w-4 text-accent" />
              <span>Real-time market data</span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-12 gap-8">
          {/* Left Column - Matching Engine */}
          <div className="col-span-12 lg:col-span-4">
            <MatchingEngine onSearch={handleSearch} />
          </div>

          {/* Right Column - Project Results */}
          <div className="col-span-12 lg:col-span-8">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-semibold text-foreground">Project Results</h2>
                  <p className="text-sm text-muted-foreground">
                    {filteredProjects.length} projects match your criteria
                  </p>
                </div>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                {filteredProjects.map((project) => (
                  <ProjectCard
                    key={project.id}
                    project={project}
                    onClick={() => handleProjectClick(project.id)}
                  />
                ))}
              </div>

              {filteredProjects.length === 0 && (
                <div className="text-center py-12">
                  <div className="text-muted-foreground">
                    <Leaf className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-medium mb-2">No projects found</h3>
                    <p className="text-sm">Try adjusting your search criteria to find more projects.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}